import { useEffect, useMemo, useState } from "react";
import type { FormEvent } from "react";
import {
  Activity, ArrowDownRight, ArrowRight, ArrowUpRight, Bell, CalendarDays, Check, CheckCircle2,
  ChevronDown, ClipboardList, Clock3, Download, FileClock, LayoutDashboard, LogIn, LogOut,
  Menu, Plus, Search, ShieldCheck, Truck, UserRound, Users, X
} from "lucide-react";
import { onAuthStateChanged, signInAnonymously, signInWithPopup, signOut, type User } from "firebase/auth";
import { collection, doc, limit, onSnapshot, orderBy, query, where } from "firebase/firestore";
import { auth, configured, db, googleProvider } from "./firebase";
import { call } from "./actions";
import RosterPanel from "./RosterPanel";
import WorkerPortal from "./WorkerPortal";
import LocationPrompt from "./LocationPrompt";
import { getMarkLocation } from "./workerActions";
import "./schedule.css";
import type { Adjustment, AuditEntry, Incident, Mark, MarkType, Personnel, Profile } from "./types";

type View = "inicio" | "marcaciones" | "incidencias" | "equipo" | "reportes" | "auditoria";
const TZ = "America/Lima";
const err = (error: unknown) => {
  const message = (error as { message?: string })?.message ?? "Ocurrió un error.";
  if ((error as { code?: string })?.code === "permission-denied" || message.includes("Missing or insufficient permissions")) {
    return "Esta cuenta aún no está autorizada.";
  }
  return message.replace(/^functions\/[^:]+:\s*/, "");
};
const dayKey = (date = new Date()) => new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" }).format(date);
const dateLabel = (date = new Date()) => new Intl.DateTimeFormat("es-PE", { timeZone: TZ, weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(date);
const timeLabel = (date?: Date) => date ? new Intl.DateTimeFormat("es-PE", { timeZone: TZ, hour: "2-digit", minute: "2-digit", hour12: false }).format(date) : "—";
const dateTimeLabel = (date?: Date) => date ? `${new Intl.DateTimeFormat("es-PE", { timeZone: TZ, day: "2-digit", month: "2-digit", year: "numeric" }).format(date)} · ${timeLabel(date)}` : "—";
const initial = (name: string) => name.trim().split(/\s+/).slice(0, 2).map(s => s[0]?.toUpperCase()).join("");
const mapsUrl = (mark: Mark) => mark.location?.status === "captured"
  ? `https://www.google.com/maps/search/?api=1&query=${mark.location.lat}%2C${mark.location.lng}` : "";
const csvCell = (value: unknown) => {
  const raw = String(value ?? "");
  const safe = /^[=+@\-\t\r]/.test(raw) ? `'${raw}` : raw;
  return `"${safe.replaceAll('"', '""')}"`;
};
const enrichMark = (mark: Mark): Mark => {
  if (!mark.occurredAt) return { ...mark, status: "registrada", lateMinutes: 0 };
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: TZ, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(mark.occurredAt.toDate());
  const minute = Number(parts.find(p => p.type === "hour")?.value) * 60 + Number(parts.find(p => p.type === "minute")?.value);
  if (mark.type === "salida") {
    if (!mark.scheduleEnd) return { ...mark, status: "registrada", lateMinutes: 0 };
    const [endHour, endMinute] = mark.scheduleEnd.split(":").map(Number);
    const difference = minute - (endHour * 60 + endMinute);
    return { ...mark, status: difference < 0 ? "salida-anticipada" : difference > 0 ? "salida-posterior" : "salida-a-tiempo", lateMinutes: 0 };
  }
  const [hour, startMinute] = mark.scheduleStart.split(":").map(Number);
  const lateMinutes = Math.max(0, minute - (hour * 60 + startMinute + mark.graceMinutes));
  return { ...mark, lateMinutes, status: lateMinutes > 0 ? "tarde" : "puntual" };
};
const statusLabel = (status: string) => ({ "salida-anticipada": "Antes de horario", "salida-posterior": "Después de horario", "salida-a-tiempo": "A horario" } as Record<string, string>)[status] ?? status;

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [accessMessage, setAccessMessage] = useState("");
  const [view, setView] = useState<View>("inicio");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [marks, setMarks] = useState<Mark[]>([]);
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [adjustments, setAdjustments] = useState<Adjustment[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [personnel, setPersonnel] = useState<Personnel[]>([]);
  const [audit, setAudit] = useState<AuditEntry[]>([]);
  const [reportMarks, setReportMarks] = useState<Mark[]>([]);
  const [reportAdjustments, setReportAdjustments] = useState<Adjustment[]>([]);
  const [reportLoaded, setReportLoaded] = useState({ marks: false, adjustments: false });
  const [busy, setBusy] = useState("");
  const [notice, setNotice] = useState("");
  const [modal, setModal] = useState<"incident" | "invite" | null>(null);
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [markingType, setMarkingType] = useState<MarkType | null>(null);
  const [markError, setMarkError] = useState("");
  const [search, setSearch] = useState("");
  const [reportMode, setReportMode] = useState<"month" | "day">("month");
  const [reportMonth, setReportMonth] = useState(dayKey().slice(0, 7));
  const [reportDay, setReportDay] = useState(dayKey());

  useEffect(() => {
    if (!auth) { setAuthReady(true); return; }
    return onAuthStateChanged(auth, next => { setUser(next); setProfile(null); setAuthReady(true); setAccessMessage(""); });
  }, []);

  useEffect(() => {
    if (!user || user.isAnonymous || !db) return;
    let cancelled = false;
    call("claimAccess").catch(error => { if (!cancelled) setAccessMessage(err(error)); });
    const stop = onSnapshot(doc(db, "users", user.uid), snap => {
      if (!cancelled) setProfile(snap.exists() ? { id: snap.id, ...snap.data() } as Profile : null);
    }, error => { if (!cancelled) setAccessMessage(err(error)); });
    return () => { cancelled = true; stop(); };
  }, [user]);

  useEffect(() => {
    if (!profile?.active || user?.isAnonymous || !db) return;
    const manager = profile.role === "encargado";
    const load = <T extends { id: string }>(name: string, q: ReturnType<typeof query>, setter: (items: T[]) => void) =>
      onSnapshot(q, snap => setter(snap.docs.map(d => ({ id: d.id, ...(d.data() as Record<string, unknown>) }) as T)), error => setNotice(`${name}: ${err(error)}`));
    const stops = [
      load<Mark>("Marcaciones", manager ? query(collection(db, "marks"), orderBy("dayKey", "desc"), limit(500)) : query(collection(db, "marks"), where("userId", "==", profile.id), orderBy("dayKey", "desc"), limit(100)), items => setMarks(items.map(enrichMark))),
      load<Incident>("Incidencias", manager ? query(collection(db, "incidents"), orderBy("createdAt", "desc"), limit(300)) : query(collection(db, "incidents"), where("userId", "==", profile.id), orderBy("createdAt", "desc"), limit(100)), setIncidents),
      load<Adjustment>("Correcciones", manager ? query(collection(db, "adjustments"), orderBy("dayKey", "desc"), limit(300)) : query(collection(db, "adjustments"), where("userId", "==", profile.id), orderBy("dayKey", "desc"), limit(100)), setAdjustments)
    ];
    if (manager) {
      stops.push(load<Profile>("Equipo", query(collection(db, "users"), limit(300)), setProfiles));
      stops.push(load<AuditEntry>("Auditoría", query(collection(db, "audit"), orderBy("at", "desc"), limit(300)), setAudit));
    }
    return () => stops.forEach(stop => stop());
  }, [profile?.id, profile?.active, profile?.role, user?.isAnonymous]);

  useEffect(() => {
    if (profile?.role !== "encargado" || !db) return;
    return onSnapshot(collection(db, "personnel"), snap =>
      setPersonnel(snap.docs.map(d => ({ id: d.id, ...d.data() } as Personnel))),
      error => setNotice(`Personal: ${err(error)}`));
  }, [profile?.role]);

  useEffect(() => {
    if (view !== "reportes" || profile?.role !== "encargado" || !db) return;
    setReportMarks([]); setReportAdjustments([]); setReportLoaded({ marks: false, adjustments: false });
    const [year, month] = reportMonth.split("-").map(Number);
    const start = `${reportMonth}-01`;
    const end = new Date(Date.UTC(year, month, 1)).toISOString().slice(0, 10);
    const marksQuery = reportMode === "day"
      ? query(collection(db, "marks"), where("dayKey", "==", reportDay))
      : query(collection(db, "marks"), where("dayKey", ">=", start), where("dayKey", "<", end), orderBy("dayKey"));
    const adjustmentsQuery = reportMode === "day"
      ? query(collection(db, "adjustments"), where("dayKey", "==", reportDay))
      : query(collection(db, "adjustments"), where("dayKey", ">=", start), where("dayKey", "<", end), orderBy("dayKey"));
    const stopMarks = onSnapshot(marksQuery,
      snap => { setReportMarks(snap.docs.map(d => enrichMark({ id: d.id, ...d.data() } as Mark))); setReportLoaded(current => ({ ...current, marks: true })); }, error => setNotice(`Reporte: ${err(error)}`));
    const stopAdjustments = onSnapshot(adjustmentsQuery,
      snap => { setReportAdjustments(snap.docs.map(d => ({ id: d.id, ...d.data() } as Adjustment))); setReportLoaded(current => ({ ...current, adjustments: true })); }, error => setNotice(`Correcciones: ${err(error)}`));
    return () => { stopMarks(); stopAdjustments(); };
  }, [view, profile?.role, reportMode, reportMonth, reportDay]);

  const today = dayKey();
  const myToday = marks.filter(m => m.userId === profile?.id && m.dayKey === today);
  const entry = myToday.find(m => m.type === "entrada");
  const exit = myToday.find(m => m.type === "salida");
  const pending = incidents.filter(i => i.status === "pendiente");
  const selectedMarks = view === "reportes" ? reportMarks : marks.filter(m => reportMode === "day" ? m.dayKey === reportDay : m.dayKey.startsWith(reportMonth));
  const selectedAdjustments = view === "reportes" ? reportAdjustments : adjustments.filter(a => reportMode === "day" ? a.dayKey === reportDay : a.dayKey.startsWith(reportMonth));
  const lateCount = selectedMarks.filter(m => m.type === "entrada" && m.lateMinutes > 0).length;
  const activeCount = personnel.filter(p => p.active).length;
  const enteredToday = new Set(marks.filter(m => m.dayKey === today && m.type === "entrada" && m.personnelId).map(m => m.personnelId));
  const withoutEntry = personnel.filter(p => p.active && !enteredToday.has(p.dni));
  const displayName = profile?.displayName || user?.displayName || "Usuario";
  const manager = profile?.role === "encargado";

  const adjustedMap = useMemo(() => new Map((view === "reportes" ? reportAdjustments : adjustments).map(a => [`${a.personnelId ?? a.userId}_${a.dayKey}_${a.type}`, a])), [adjustments, reportAdjustments, view]);
  const reportRows = [
    ...selectedMarks.map(mark => {
      const person = personnel.find(p => p.dni === mark.personnelId);
      const correction = adjustedMap.get(`${mark.personnelId ?? mark.userId}_${mark.dayKey}_${mark.type}`);
      const location = mark.location;
      return {
        id: mark.id, date: mark.dayKey, name: mark.displayName, dni: mark.personnelId ?? "",
        company: person?.companies.join("/") ?? "", type: mark.type,
        original: dateTimeLabel(mark.occurredAt?.toDate()), corrected: correction ? dateTimeLabel(correction.correctedAt?.toDate()) : "",
        scheduledStart: mark.scheduleStart, scheduledEnd: mark.scheduleEnd || "Variable",
        status: statusLabel(mark.status), late: mark.lateMinutes,
        location: location?.status === "captured" ? `${location.lat}, ${location.lng}` : "Sin ubicación",
        maps: mapsUrl(mark), sortTime: mark.occurredAt?.toDate().getTime() ?? 0
      };
    }),
    ...selectedAdjustments.filter(a => !a.originalMarkId).map(correction => {
      const person = personnel.find(p => p.dni === correction.personnelId);
      const incident = incidents.find(i => i.id === correction.incidentId);
      return {
        id: `correction_${correction.id}`, date: correction.dayKey,
        name: incident?.displayName ?? person?.displayName ?? profiles.find(p => p.id === correction.userId)?.displayName ?? "Persona sin nombre",
        dni: correction.personnelId ?? person?.dni ?? "", company: person?.companies.join("/") ?? "",
        type: correction.type, original: "Sin marcación", corrected: dateTimeLabel(correction.correctedAt?.toDate()),
        scheduledStart: person?.scheduleStart ?? "", scheduledEnd: person?.scheduleEnd || "Variable",
        status: "Corrección aprobada", late: "" as const, location: "Sin ubicación", maps: "",
        sortTime: correction.correctedAt?.toDate().getTime() ?? 0
      };
    })
  ].sort((a, b) => a.date.localeCompare(b.date) || a.sortTime - b.sortTime);
  const reportPeriod = reportMode === "day" ? reportDay : reportMonth;
  const reportReady = reportLoaded.marks && reportLoaded.adjustments;
  const shownMarks = useMemo(() => marks.filter(m => `${m.displayName} ${m.dayKey} ${m.type}`.toLowerCase().includes(search.toLowerCase())), [marks, search]);

  async function perform(name: string, data: unknown, success: string) {
    setBusy(name); setNotice("");
    try { await call(name, data); setNotice(success); setModal(null); setSelectedIncident(null); }
    catch (error) { setNotice(err(error)); }
    finally { setBusy(""); }
  }

  async function confirmManagerMark() {
    if (!markingType) return;
    setBusy("markAttendance"); setMarkError("");
    try {
      const location = await getMarkLocation();
      await call("markAttendance", { type: markingType, location });
      setNotice(`${markingType === "entrada" ? "Entrada" : "Salida"} registrada con ubicación.`);
      setMarkingType(null);
    } catch (error) { setMarkError(err(error)); }
    finally { setBusy(""); }
  }

  async function downloadReport() {
    try {
      const { default: ExcelJS } = await import("exceljs");
      const book = new ExcelJS.Workbook();
      const sheet = book.addWorksheet("Asistencia");
      sheet.columns = [
        { header: "Fecha", key: "date", width: 14 }, { header: "Trabajador", key: "name", width: 35 },
        { header: "DNI", key: "dni", width: 15 }, { header: "Empresa", key: "company", width: 15 },
        { header: "Tipo", key: "type", width: 14 }, { header: "Hora original", key: "original", width: 23 },
        { header: "Hora corregida", key: "corrected", width: 23 }, { header: "Horario entrada", key: "scheduledStart", width: 18 },
        { header: "Horario salida", key: "scheduledEnd", width: 18 }, { header: "Estado", key: "status", width: 22 },
        { header: "Tardanza (min)", key: "late", width: 18 }, { header: "Ubicación", key: "location", width: 18 },
        { header: "Google Maps", key: "maps", width: 55 }
      ];
      for (const row of reportRows) sheet.addRow(row);
      sheet.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };
      sheet.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF173259" } };
      sheet.autoFilter = { from: "A1", to: `M${Math.max(2, sheet.rowCount)}` };
      sheet.views = [{ state: "frozen", ySplit: 1 }];
      const buffer = await book.xlsx.writeBuffer();
      const url = URL.createObjectURL(new Blob([new Uint8Array(buffer as ArrayBuffer)], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }));
      const link = document.createElement("a"); link.href = url; link.download = `asistencia-os-${reportPeriod}.xlsx`; link.click(); URL.revokeObjectURL(url);
    } catch (error) { setNotice(err(error)); }
  }

  async function downloadPdf() {
    try {
      const [{ jsPDF }, { default: autoTable }] = await Promise.all([import("jspdf"), import("jspdf-autotable")]);
      const pdf = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
      pdf.setFont("helvetica", "bold"); pdf.setFontSize(17); pdf.setTextColor(23, 50, 89);
      pdf.text("O.S. Logistics | Reporte de asistencia", 14, 17);
      pdf.setFont("helvetica", "normal"); pdf.setFontSize(10); pdf.setTextColor(80, 97, 122);
      pdf.text(`${reportMode === "day" ? "Día" : "Mes"}: ${reportPeriod}  |  Horario de referencia: Lima (UTC-05:00)`, 14, 25);
      pdf.text(`Marcaciones: ${selectedMarks.length}  |  Entradas: ${selectedMarks.filter(m => m.type === "entrada").length}  |  Tardanzas: ${lateCount}  |  Correcciones aprobadas: ${selectedAdjustments.length}`, 14, 31);
      autoTable(pdf, {
        startY: 37,
        head: [["Fecha", "Trabajador", "DNI", "Tipo", "Hora original", "Hora corregida", "Estado", "Tardanza", "Ubicación"]],
        body: reportRows.length ? reportRows.map(r => [r.date, r.name, r.dni, r.type, r.original, r.corrected || "-", r.status, typeof r.late === "number" && r.late > 0 ? `${r.late} min` : "-", r.location]) : [["Sin registros", "", "", "", "", "", "", "", ""]],
        styles: { font: "helvetica", fontSize: 8, cellPadding: 2.5, overflow: "linebreak" },
        headStyles: { fillColor: [23, 50, 89], textColor: 255 },
        alternateRowStyles: { fillColor: [245, 248, 252] },
        columnStyles: { 1: { cellWidth: 57 }, 8: { cellWidth: 45 } },
        margin: { left: 14, right: 14, bottom: 15 },
        didDrawPage: data => { pdf.setFontSize(8); pdf.setTextColor(110, 125, 145); pdf.text(`Página ${data.pageNumber}`, 280, 200, { align: "right" }); }
      });
      pdf.save(`asistencia-os-${reportPeriod}.pdf`);
    } catch (error) { setNotice(err(error)); }
  }

  if (!configured) return <div className="setup-page"><div className="setup-card"><div className="brand-mark"><Truck size={28} /></div><h1>Configura Firebase para comenzar</h1><p>La aplicación está preparada. Copia <code>.env.example</code> a <code>.env.local</code> y completa los datos de configuración de la app web registrada en el proyecto <strong>sistema-de-asistencia-os</strong>.</p><p>Luego habilita Google Authentication y sigue los pasos de activación de Firestore y Hosting en el archivo README.</p></div></div>;
  if (!authReady) return <div className="loading-page">Cargando asistencia…</div>;
  if (!user) return <div className="login-page"><div className="login-left"><div className="login-top"><div className="brand-mark"><Truck size={28} /></div><span>O.S. LOGISTICS</span></div><div className="login-copy"><span className="eyebrow light">SISTEMA DE ASISTENCIA</span><h1>Tu jornada,<br /><em>en orden.</em></h1><p>Marca tu entrada y salida, consulta tus registros y gestiona incidencias desde un solo lugar.</p><div className="login-feature"><ShieldCheck size={19} /> Registros seguros con hora del servidor</div></div><div className="login-footer">© {new Date().getFullYear()} O.S. Logistics</div></div><div className="login-right"><div className="login-panel"><div className="mobile-brand"><div className="brand-mark"><Truck size={24} /></div> O.S. LOGISTICS</div><div className="login-icon"><Clock3 size={29} /></div><span className="eyebrow">BIENVENIDO</span><h2>Control de asistencia</h2><p>Si trabajas en OS o SLI, registra este celular una sola vez. Después podrás marcar con un toque.</p><button className="google-button" onClick={() => auth && signInAnonymously(auth).catch(e => setNotice(err(e)))}>Soy trabajador <ArrowRight size={18} /></button><button className="secondary-button manager-login-button" onClick={() => auth && signInWithPopup(auth, googleProvider).catch(e => setNotice(err(e)))}>Acceso del encargado con Google</button>{notice && <div className="inline-alert">{notice}</div>}<div className="login-help"><ShieldCheck size={16} /> Acceso exclusivo para personal autorizado</div></div></div></div>;
  if (user.isAnonymous) return <WorkerPortal user={user} />;
  if (!profile || !profile.active) return <div className="setup-page"><div className="setup-card"><div className="brand-mark"><Truck size={28} /></div><h1>Acceso pendiente</h1><p>Tu sesión de Google está activa, pero tu cuenta aún no tiene acceso. Solicita al encargado que autorice tu cuenta.</p>{accessMessage && <div className="inline-alert">{accessMessage}</div>}<div className="pending-actions"><button className="primary-button" onClick={() => call("claimAccess").catch(e => setAccessMessage(err(e)))}>Volver a comprobar</button><button className="secondary-button" onClick={() => signOut(auth!)}>Cerrar sesión</button></div></div></div>;

  const nav: { id: View; label: string; icon: typeof LayoutDashboard }[] = [
    { id: "inicio", label: "Inicio", icon: LayoutDashboard },
    { id: "marcaciones", label: "Marcaciones", icon: Clock3 },
    { id: "incidencias", label: "Incidencias", icon: ClipboardList },
    ...(manager ? [{ id: "equipo" as View, label: "Equipo", icon: Users }, { id: "reportes" as View, label: "Reportes", icon: FileClock }, { id: "auditoria" as View, label: "Auditoría", icon: ShieldCheck }] : [])
  ];
  const navigate = (next: View) => { setView(next); setMobileMenu(false); setNotice(""); };

  return <div className="app-shell">
    {mobileMenu && <div className="mobile-overlay" onClick={() => setMobileMenu(false)} />}
    <aside className={`sidebar ${mobileMenu ? "open" : ""}`}>
      <div className="sidebar-brand"><div className="brand-mark"><Truck size={25} /></div><div><strong>O.S. LOGISTICS</strong><small>CONTROL DE ASISTENCIA</small></div></div>
      <div className="nav-label">ESPACIO DE TRABAJO</div>
      <nav>{nav.map(item => <button key={item.id} className={`nav-item ${view === item.id ? "active" : ""}`} onClick={() => navigate(item.id)}><item.icon size={19} /><span>{item.label}</span>{item.id === "incidencias" && manager && pending.length > 0 && <b>{pending.length}</b>}</button>)}</nav>
      <div className="sidebar-spacer" />
      <div className="sidebar-help"><div className="help-icon"><ShieldCheck size={20} /></div><strong>Registros confiables</strong><span>Las marcaciones originales se conservan para auditoría.</span></div>
      <button className="sidebar-user" onClick={() => signOut(auth!)}><div className="avatar">{initial(displayName)}</div><div><strong>{displayName}</strong><small>{manager ? "Encargado" : "Trabajador"}</small></div><LogOut size={17} /></button>
    </aside>
    <div className="main-area">
      <header className="topbar"><button className="icon-button menu-button" onClick={() => setMobileMenu(true)}><Menu size={22} /></button><div className="breadcrumb">O.S. Logistics <span>/</span> <strong>{nav.find(n => n.id === view)?.label}</strong></div><div className="topbar-right"><span className="top-date"><CalendarDays size={16} /> {dateLabel()}</span><div className="top-avatar">{initial(displayName)}</div></div></header>
      <main className="content">
        {notice && <div className="notice"><span>{notice}</span><button onClick={() => setNotice("")}><X size={16} /></button></div>}
        {view === "inicio" && <>
          <div className="page-heading"><div><div className="eyebrow">PANEL GENERAL</div><h1>Hola, {displayName.split(" ")[0]} <span className="wave">👋</span></h1><p>Aquí tienes el resumen de asistencia de hoy.</p></div><div className="date-chip"><CalendarDays size={17} /> {dateLabel()}</div></div>
          <div className="hero-grid"><section className="clock-card"><div className="card-top"><span className="mini-label">MI JORNADA DE HOY</span><span className="live-pill"><i /> EN VIVO</span></div><div className="clock-card-main"><div><div className="clock-caption">Hora referencial en Lima</div><LiveClock /><div className="timezone">La marcación usa la hora del servidor</div></div><div className="clock-art"><Clock3 size={104} strokeWidth={1} /></div></div><div className="clock-divider" /><div className="clock-actions"><div className="clock-state"><span>Entrada</span><strong>{timeLabel(entry?.occurredAt?.toDate())}</strong></div><div className="clock-state"><span>Salida</span><strong>{timeLabel(exit?.occurredAt?.toDate())}</strong></div><button className="mark-button" disabled={Boolean(busy) || Boolean(exit)} onClick={() => { setMarkError(""); setMarkingType(entry ? "salida" : "entrada"); }}>{busy === "markAttendance" ? "Registrando…" : exit ? "Jornada completada" : entry ? "Marcar salida" : "Marcar entrada"} <ArrowRight size={18} /></button></div></section>
          <section className="summary-card"><div className="section-title"><span>Resumen del mes</span><span className="small-muted">{new Intl.DateTimeFormat("es-PE", { month: "long", year: "numeric" }).format(new Date())}</span></div><div className="summary-row"><div className="summary-icon blue"><CheckCircle2 size={20} /></div><div><span>Marcaciones</span><strong>{marks.filter(m => m.userId === profile.id && m.dayKey.startsWith(today.slice(0, 7))).length}</strong></div><ArrowUpRight size={18} /></div><div className="summary-row"><div className="summary-icon orange"><Clock3 size={20} /></div><div><span>Tardanzas</span><strong>{marks.filter(m => m.userId === profile.id && m.dayKey.startsWith(today.slice(0, 7)) && m.lateMinutes > 0).length}</strong></div><ArrowDownRight size={18} /></div><div className="summary-row"><div className="summary-icon purple"><ClipboardList size={20} /></div><div><span>Incidencias pendientes</span><strong>{incidents.filter(i => i.userId === profile.id && i.status === "pendiente").length}</strong></div><ArrowRight size={18} /></div></section></div>
          {manager && <><div className="stats-grid"><Stat label="Personal activo" value={activeCount} icon={Users} tone="blue" /><Stat label="Entradas hoy" value={activeCount - withoutEntry.length} icon={LogIn} tone="green" /><Stat label="Sin entrada hoy" value={withoutEntry.length} icon={Clock3} tone="orange" /><Stat label="Incidencias por revisar" value={pending.length} icon={Bell} tone="purple" /></div><section className="panel missing-panel"><div className="panel-heading"><div><h2>Sin entrada registrada hoy</h2><p>Personal activo de OS y SLI que aún no marcó. No equivale a una ausencia.</p></div></div><div className="missing-list">{withoutEntry.map(person => <div key={person.dni}><strong>{person.displayName}</strong><span>{person.companies.join("/")} · {person.occupation}</span></div>)}{withoutEntry.length === 0 && <p>Todo el personal activo tiene entrada registrada.</p>}</div></section></>}
          <div className="two-columns"><section className="panel"><div className="panel-heading"><div><h2>Actividad reciente</h2><p>Tus últimos movimientos registrados</p></div><button className="text-button" onClick={() => navigate("marcaciones")}>Ver todo <ArrowRight size={16} /></button></div><div className="activity-list">{marks.filter(m => m.userId === profile.id).slice(0, 5).map(m => <div className="activity-item" key={m.id}><div className={`activity-icon ${m.type === "entrada" ? "green" : "blue"}`}>{m.type === "entrada" ? <LogIn size={18} /> : <LogOut size={18} />}</div><div><strong>{m.type === "entrada" ? "Entrada registrada" : "Salida registrada"}</strong><span>{m.dayKey} · {timeLabel(m.occurredAt?.toDate())}</span></div><Status status={m.status} /></div>)}{marks.filter(m => m.userId === profile.id).length === 0 && <Empty text="Aún no tienes marcaciones." />}</div></section><section className="panel quick-panel"><div className="panel-heading"><div><h2>Accesos rápidos</h2><p>Lo que necesitas a un clic</p></div></div><button className="quick-action" onClick={() => setModal("incident")}><div className="quick-icon purple"><Plus size={20} /></div><div><strong>Reportar incidencia</strong><span>Solicita una corrección de horario</span></div><ArrowRight size={18} /></button><button className="quick-action" onClick={() => navigate("marcaciones")}><div className="quick-icon blue"><FileClock size={20} /></div><div><strong>Ver mis marcaciones</strong><span>Consulta tu historial completo</span></div><ArrowRight size={18} /></button>{manager && <button className="quick-action" onClick={() => navigate("equipo")}><div className="quick-icon orange"><Users size={20} /></div><div><strong>Gestionar equipo</strong><span>Revisa accesos y horarios</span></div><ArrowRight size={18} /></button>}</section></div>
        </>}
        {view === "marcaciones" && <><PageHeader eyebrow="REGISTROS" title="Marcaciones" description="Entradas y salidas con hora oficial del servidor." action={<button className="primary-button" onClick={() => setModal("incident")}><Plus size={17} /> Reportar incidencia</button>} /><div className="panel table-panel"><div className="table-toolbar"><div className="search-box"><Search size={18} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por nombre, fecha o tipo" /></div><span className="record-count">{shownMarks.length} registros</span></div><div className="table-scroll"><table><thead><tr><th>FECHA</th>{manager && <th>TRABAJADOR</th>}<th>TIPO</th><th>HORA ORIGINAL</th><th>ESTADO</th><th>CORRECCIÓN</th>{manager && <th>UBICACIÓN</th>}</tr></thead><tbody>{shownMarks.map(m => { const a = adjustedMap.get(`${m.personnelId ?? m.userId}_${m.dayKey}_${m.type}`); return <tr key={m.id}><td className="strong-cell">{m.dayKey}</td>{manager && <td>{m.displayName}</td>}<td><span className={`type-pill ${m.type}`}>{m.type === "entrada" ? <LogIn size={14} /> : <LogOut size={14} />}{m.type}</span></td><td>{timeLabel(m.occurredAt?.toDate())}</td><td><Status status={m.status} /></td><td>{a ? <span className="adjusted">{timeLabel(a.correctedAt.toDate())} <Check size={14} /></span> : "—"}</td>{manager && <td>{mapsUrl(m) ? <a href={mapsUrl(m)} target="_blank" rel="noreferrer">Ver en Maps</a> : "Sin ubicación"}</td>}</tr>})}</tbody></table>{shownMarks.length === 0 && <Empty text="No hay marcaciones para mostrar." />}</div></div></>}
        {view === "incidencias" && <><PageHeader eyebrow="SOLICITUDES" title="Incidencias" description={manager ? "Revisa y resuelve solicitudes de corrección." : "Solicita ajustes sin alterar tus marcaciones originales."} action={<button className="primary-button" onClick={() => setModal("incident")}><Plus size={17} /> Nueva incidencia</button>} /><div className="incident-grid">{incidents.map(i => <div className="incident-card" key={i.id}><div className="incident-top"><span className="incident-date"><CalendarDays size={15} /> {i.dayKey}</span><Status status={i.status} /></div><h3>{i.type === "entrada" ? "Corrección de entrada" : "Corrección de salida"}</h3><p>{i.reason}</p><div className="incident-meta"><span><UserRound size={15} /> {i.displayName}</span><span><Clock3 size={15} /> Propuesta: {timeLabel(i.proposedAt?.toDate())}</span></div>{i.resolutionNote && <div className="resolution-note">Respuesta: {i.resolutionNote}</div>}{manager && i.status === "pendiente" && <button className="review-button" onClick={() => setSelectedIncident(i)}>Revisar solicitud <ArrowRight size={16} /></button>}</div>)}{incidents.length === 0 && <div className="panel"><Empty text="No hay incidencias registradas." /></div>}</div></>}
        {view === "equipo" && manager && <><PageHeader eyebrow="PERSONAL" title="Equipo" description="Aprueba celulares, actualiza el padrón y gestiona las bajas." /><RosterPanel personnel={personnel} /></>}
        {view === "reportes" && manager && <>
          <PageHeader eyebrow="ANÁLISIS" title="Reportes" description="Consulta la asistencia por día o por mes y descárgala en Excel o PDF." />
          <div className="report-toolbar">
            <div className="report-period-controls">
              <div className="report-mode" role="group" aria-label="Período del reporte">
                <button type="button" className={reportMode === "month" ? "selected" : ""} onClick={() => setReportMode("month")}>Mes</button>
                <button type="button" className={reportMode === "day" ? "selected" : ""} onClick={() => setReportMode("day")}>Día</button>
              </div>
              {reportMode === "month" ? <label>Mes <input type="month" value={reportMonth} onChange={e => setReportMonth(e.target.value)} /></label>
                : <label>Fecha <input type="date" value={reportDay} max={dayKey()} onChange={e => setReportDay(e.target.value)} /></label>}
            </div>
            <div className="report-downloads"><button className="secondary-button" disabled={!reportReady} onClick={downloadReport}><Download size={17} /> Descargar Excel</button><button className="primary-button" disabled={!reportReady} onClick={downloadPdf}><Download size={17} /> Descargar PDF</button></div>
          </div>
          <p className="report-timezone">Horario de referencia: Lima (UTC−05:00)</p>
          <div className="stats-grid"><Stat label="Marcaciones" value={selectedMarks.length} icon={Activity} tone="blue" /><Stat label="Entradas" value={selectedMarks.filter(m => m.type === "entrada").length} icon={LogIn} tone="green" /><Stat label="Tardanzas" value={lateCount} icon={Clock3} tone="orange" /><Stat label="Correcciones aprobadas" value={selectedAdjustments.length} icon={CheckCircle2} tone="purple" /></div>
          <div className="panel table-panel"><div className="panel-heading"><div><h2>Detalle del {reportMode === "day" ? "día" : "mes"}</h2><p>La vista y las descargas incluyen marcas originales, correcciones y ubicación.</p></div></div><div className="table-scroll"><table><thead><tr><th>FECHA</th><th>TRABAJADOR</th><th>DNI</th><th>TIPO</th><th>HORA</th><th>HORA CORREGIDA</th><th>ESTADO</th><th>TARDANZA</th><th>UBICACIÓN</th></tr></thead><tbody>{reportReady && reportRows.map(r => <tr key={r.id}><td className="strong-cell">{r.date}</td><td>{r.name}</td><td>{r.dni || "—"}</td><td className="capitalize">{r.type}</td><td>{r.original}</td><td>{r.corrected || "—"}</td><td>{r.status}</td><td>{typeof r.late === "number" && r.late > 0 ? `${r.late} min` : "—"}</td><td>{r.maps ? <a href={r.maps} target="_blank" rel="noopener noreferrer">Ver en Maps</a> : "—"}</td></tr>)}</tbody></table>{!reportReady ? <Empty text="Cargando reporte…" /> : reportRows.length === 0 && <Empty text={`No hay datos para este ${reportMode === "day" ? "día" : "mes"}.`} />}</div></div>
        </>}
        {view === "auditoria" && manager && <><PageHeader eyebrow="TRAZABILIDAD" title="Auditoría" description="Historial de acciones realizadas en el sistema." /><div className="panel audit-list">{audit.map(a => <div className="audit-item" key={a.id}><div className="audit-icon"><ShieldCheck size={19} /></div><div><strong>{({ mark_attendance: "Marcación registrada", submit_incident: "Incidencia creada", resolve_incident: "Incidencia resuelta", invite_user: "Persona invitada", update_user: "Perfil actualizado", claim_access: "Acceso activado", roster_upsert: "Padrón actualizado", roster_delete: "Persona eliminada del padrón", worker_access_removed: "Acceso anterior eliminado", registration_approved: "Celular aprobado", registration_rejected: "Solicitud rechazada" } as Record<string, string>)[a.action] ?? a.action}</strong><span>Actor: {profiles.find(p => p.id === a.actorId)?.displayName ?? a.actorId} · Referencia: {a.targetId}</span></div><time>{dateTimeLabel(a.at?.toDate())}</time></div>)}{audit.length === 0 && <Empty text="Aún no hay acciones registradas." />}</div></>}
      </main>
    </div>
    {modal === "incident" && <IncidentModal busy={Boolean(busy)} onClose={() => setModal(null)} onSubmit={data => perform("submitIncident", data, "Incidencia enviada para revisión.")} />}
    {modal === "invite" && <InviteModal busy={Boolean(busy)} onClose={() => setModal(null)} onSubmit={data => perform("inviteUser", data, "Invitación registrada. La persona debe ingresar con Google.")} />}
    {selectedIncident && <ResolveModal incident={selectedIncident} busy={Boolean(busy)} onClose={() => setSelectedIncident(null)} onSubmit={data => perform("resolveIncident", data, "Incidencia resuelta.")} />}
    {markingType && <LocationPrompt type={markingType} busy={busy === "markAttendance"} error={markError} onConfirm={confirmManagerMark} onClose={() => setMarkingType(null)} />}
  </div>;
}

function LiveClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => { const timer = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(timer); }, []);
  return <div className="live-clock">{new Intl.DateTimeFormat("es-PE", { timeZone: TZ, hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).format(now)}</div>;
}
function Status({ status }: { status: string }) {
  return <span className={`status status-${status}`}>{statusLabel(status)}</span>;
}
function Empty({ text }: { text: string }) { return <div className="empty"><FileClock size={27} /><span>{text}</span></div>; }
function Stat({ label, value, icon: Icon, tone }: { label: string; value: number; icon: typeof Users; tone: string }) { return <div className="stat-card"><div className={`stat-icon ${tone}`}><Icon size={21} /></div><span>{label}</span><strong>{value}</strong></div>; }
function PageHeader({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: React.ReactNode }) { return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{action}</div>; }

function Modal({ title, description, onClose, children }: { title: string; description: string; onClose: () => void; children: React.ReactNode }) { return <div className="modal-backdrop" onMouseDown={onClose}><div className="modal" onMouseDown={e => e.stopPropagation()}><div className="modal-header"><div><h2>{title}</h2><p>{description}</p></div><button className="icon-button" onClick={onClose}><X size={20} /></button></div>{children}</div></div>; }
function IncidentModal({ busy, onClose, onSubmit }: { busy: boolean; onClose: () => void; onSubmit: (data: unknown) => void }) {
  const [day, setDay] = useState(dayKey()); const [type, setType] = useState<MarkType>("entrada"); const [time, setTime] = useState("08:00"); const [reason, setReason] = useState("");
  const submit = (e: FormEvent) => { e.preventDefault(); onSubmit({ dayKey: day, type, proposedAt: `${day}T${time}:00-05:00`, reason }); };
  return <Modal title="Nueva incidencia" description="Explica la corrección que solicitas. El registro original se conservará." onClose={onClose}><form onSubmit={submit} className="modal-form"><div className="form-grid"><label>Fecha<input required type="date" value={day} max={dayKey()} onChange={e => setDay(e.target.value)} /></label><label>Marcación<select value={type} onChange={e => setType(e.target.value as MarkType)}><option value="entrada">Entrada</option><option value="salida">Salida</option></select></label></div><label>Hora correcta propuesta<input required type="time" value={time} onChange={e => setTime(e.target.value)} /></label><label>Motivo<textarea required minLength={5} maxLength={1000} value={reason} onChange={e => setReason(e.target.value)} placeholder="Describe qué ocurrió y por qué se necesita la corrección" rows={4} /></label><div className="modal-actions"><button type="button" className="secondary-button" onClick={onClose}>Cancelar</button><button className="primary-button" disabled={busy}>{busy ? "Enviando…" : "Enviar solicitud"}</button></div></form></Modal>;
}
function InviteModal({ busy, onClose, onSubmit }: { busy: boolean; onClose: () => void; onSubmit: (data: unknown) => void }) {
  const [email, setEmail] = useState(""); const [displayName, setDisplayName] = useState(""); const [role, setRole] = useState("trabajador"); const [scheduleStart, setScheduleStart] = useState("08:00"); const [graceMinutes, setGraceMinutes] = useState(10);
  return <Modal title="Invitar persona" description="Autoriza su Gmail personal para acceder al sistema." onClose={onClose}><form className="modal-form" onSubmit={e => { e.preventDefault(); onSubmit({ email, displayName, role, scheduleStart, graceMinutes }); }}><label>Nombre completo<input required value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder="Nombre y apellido" /></label><label>Correo Gmail<input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="persona@gmail.com" /></label><div className="form-grid"><label>Rol<select value={role} onChange={e => setRole(e.target.value)}><option value="trabajador">Trabajador</option><option value="encargado">Encargado</option></select></label><label>Hora de entrada<input required type="time" value={scheduleStart} onChange={e => setScheduleStart(e.target.value)} /></label></div><label>Tolerancia en minutos<input required type="number" min={0} max={120} value={graceMinutes} onChange={e => setGraceMinutes(Number(e.target.value))} /></label><div className="modal-actions"><button type="button" className="secondary-button" onClick={onClose}>Cancelar</button><button className="primary-button" disabled={busy}>{busy ? "Guardando…" : "Crear invitación"}</button></div></form></Modal>;
}
function ResolveModal({ incident, busy, onClose, onSubmit }: { incident: Incident; busy: boolean; onClose: () => void; onSubmit: (data: unknown) => void }) {
  const [note, setNote] = useState("");
  return <Modal title="Revisar incidencia" description={`${incident.displayName} · ${incident.dayKey} · ${incident.type}`} onClose={onClose}><div className="review-detail"><strong>Hora propuesta: {timeLabel(incident.proposedAt?.toDate())}</strong><p>{incident.reason}</p></div><label className="modal-field">Nota de resolución<textarea required maxLength={500} rows={3} value={note} onChange={e => setNote(e.target.value)} placeholder="Explica la decisión para dejar constancia" /></label><div className="modal-actions"><button className="secondary-button" disabled={busy || !note.trim()} onClick={() => onSubmit({ id: incident.id, decision: "rechazar", note })}>Rechazar</button><button className="primary-button" disabled={busy || !note.trim()} onClick={() => onSubmit({ id: incident.id, decision: "aprobar", note })}>{busy ? "Guardando…" : "Aprobar corrección"}</button></div></Modal>;
}
function TeamRow({ profile, busy, onSave }: { profile: Profile; busy: boolean; onSave: (data: { scheduleStart: string; graceMinutes: number; active: boolean }) => void }) {
  const [editing, setEditing] = useState(false); const [scheduleStart, setScheduleStart] = useState(profile.scheduleStart); const [graceMinutes, setGraceMinutes] = useState(profile.graceMinutes); const [active, setActive] = useState(profile.active);
  return <tr><td><div className="person-cell"><div className="mini-avatar">{initial(profile.displayName)}</div><div><strong>{profile.displayName}</strong><span>{profile.email}</span></div></div></td><td className="capitalize">{profile.role}</td><td>{editing ? <input className="table-input" type="time" value={scheduleStart} onChange={e => setScheduleStart(e.target.value)} /> : profile.scheduleStart}</td><td>{editing ? <input className="table-input number" type="number" min={0} max={120} value={graceMinutes} onChange={e => setGraceMinutes(Number(e.target.value))} /> : `${profile.graceMinutes} min`}</td><td>{editing ? <select value={active ? "active" : "inactive"} onChange={e => setActive(e.target.value === "active")}><option value="active">Activo</option><option value="inactive">Inactivo</option></select> : <Status status={profile.active ? "activo" : "inactivo"} />}</td><td>{editing ? <button className="text-button" disabled={busy} onClick={() => { onSave({ scheduleStart, graceMinutes, active }); setEditing(false); }}>Guardar</button> : <button className="text-button" onClick={() => setEditing(true)}>Editar</button>}</td></tr>;
}

export default App;
